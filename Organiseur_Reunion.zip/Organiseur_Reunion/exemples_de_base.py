from random import randrange
#random.randrange(start, stop, [step])
'''

def func_change_matrice(par_matrice):
    par_matrice[0] = 1

Matrice = [0,0,0,0]

func_change_matrice(list(Matrice))
print(Matrice)

a = int(00)

print(a)


Matrice = [ [0,0,0,0,1,1,0,2,4,4,5,7],(1)
            [0,0,0,0,1,1,0,2,4,4,5,7],(2)
            [0,0,0,0,1,1,0,2,4,4,5,7],(3)
            [0,0,0,0,1,1,0,2,4,4,5,7]](4)

            
Matrice2 = [ [0,0,0,0,1,1,0,2,4,4,5,7],(2)
            [0,0,0,0,1,1,0,2,4,4,5,7],(1)
            [0,0,0,0,1,1,0,2,4,4,5,7],(4)
            [0,0,0,0,1,1,0,2,4,4,5,7]](3)


print(Matrice.count(0))



Matrice = [1]
Matrice2 = [1,2]
Matrice3 = [0] * (len(Matrice) + len(Matrice2))

print(len(Matrice))
print(len(Matrice2))
print(Matrice3)



Matrice = [1,2,3,4,5]

ordre = [1,0,4,3,2]

for i in(ordre):
    print(Matrice[i])

'''

